import React, { useEffect, useState } from "react";
import { FaHtml5, FaCss3Alt, FaJs, FaReact, FaGitAlt, FaDocker } from "react-icons/fa";
import { SiTailwindcss, SiMongodb, SiFigma } from "react-icons/si";
import AOS from "aos"; // Import AOS
import "aos/dist/aos.css"; // Import AOS CSS
import "./skills.css"; // Import CSS

const Skills = () => {
  const [activeSkill, setActiveSkill] = useState(null);

  useEffect(() => {
    AOS.init({ duration: 1000, once: true }); // Initialize AOS with animation duration
  }, []);

  const skills = [
    { icon: <FaHtml5 size={40} />, name: "HTML" },
    { icon: <FaCss3Alt size={40} />, name: "CSS" },
    { icon: <FaJs size={40} />, name: "JavaScript" },
    { icon: <FaReact size={40} />, name: "React" },
    { icon: <SiTailwindcss size={40} />, name: "Tailwind CSS" },
    { icon: <SiMongodb size={40} />, name: "MongoDB" },
    { icon: <FaGitAlt size={40} />, name: "Git" },
    { icon: <SiFigma size={40} />, name: "Figma" },
    { icon: <FaDocker size={40} />, name: "Docker" },
  ];

  const handleSkillClick = (index) => {
    setActiveSkill(index);
  };

  return (
    <div className="languages-container">
      <h2 className="languages-title">Skills</h2>
      <div className="languages-grid">
        {skills.map((skill, index) => (
          <div
            key={index}
            className={`language-item ${activeSkill === index ? "active" : ""}`}
            data-aos="flip-right" // AOS rotation animation
            data-aos-duration="1000"
            onClick={() => handleSkillClick(index)} // Handle click for zoom-in
          >
            <div className="language-icon">{skill.icon}</div>
            <p className="language-name">{skill.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Skills;
