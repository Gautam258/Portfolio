import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar/navbar";
import Intro from "./components/Intro/intro";
import About from "./components/About/About";
import Experience from "./components/Experience/experience";
import Skills from "./components/Skills/skills";
import Project from "./components/Project/project";
import Contact from "./components/Contact/contact";
import Footer from "./components/Footer/footer";
import HireMe from "./components/Hire/Hire";
import Aos from "aos";
import "aos/dist/aos.css";

function App() {
  useEffect(() => {
    Aos.init();
  }, []);

  return (
    <Router>
      <Navbar /> {/* ✅ Navbar is now outside Routes, so it appears on all pages */}
      <Routes>
        {/* Home Page - Includes All Sections */}
        <Route
          path="/"
          element={
            <>
              <Intro />
              <About />
              <Experience />
              <Skills />
              <Project />
              <Contact />
              <Footer />
            </>
          }
        />
        
        {/* Hire Me Page (Navbar is still visible) */}
        <Route path="/hire" element={<HireMe />} />
      </Routes>
    </Router>
  );
}

export default App;
