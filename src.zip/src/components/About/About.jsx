import React from 'react'
import './About.css';
import UIDesign from '../../asset/image5.png'
const About = () => {
  return (
    <section id="AboutMe" className="about--section">
      <div className="about--section--img">
        <img src={UIDesign} alt="About me" />
      </div>
      <div className="hero--section--contact--box about--section--box">
        <div className="hero--section--content">
          <h1 className="skills-section--heading">About Me</h1>
          <p className="hero--section-description">
          Hello! I'm a passionate and driven MSc IT student at S.I.E.S College, Mumbai, with a strong foundation
           in Information Technology, having completed my BSc IT with an 8.13 CGPA. I bring a blend of academic 
           knowledge and practical experience, particularly in Python development and algorithmic trading.
            
          </p>
          <p className="hero--section-description">
          During my internship at Algobulls Pvt Ltd, I honed my skills in developing and optimizing algorithmic
           trading strategies using Python. This experience deepened my interest in leveraging technology to solve 
           complex problems and enhance efficiency in financial markets.



          </p>
        </div>
      </div>
    </section>
)
}

export default About