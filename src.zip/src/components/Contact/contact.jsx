import React, { useRef } from "react";
import "./Contact.css";
import emailjs from "@emailjs/browser";

const Contact = () => {
  const form = useRef();

  const sendEmail = (e) => {
    e.preventDefault();

    emailjs
      .sendForm("service_7sm9p5m", "template_zy7eka5", form.current, {
        publicKey: "Hzl05hDOtUlsxbJ0y",
      })
      .then(
        () => {
          alert("Message sent successfully!");
          e.target.reset(); // Clears the form after successful submission
          console.log("SUCCESS!");
        },
        (error) => {
          console.log("FAILED...", error.text);
        }
      );
  };

  return (
    <section id="contactPage">
      <div id="contact">
        <h1 className="contactPageTitle">Contact Me</h1>
        <span className="contactDesc">
          Have a question or idea? Feel free to reach out—I'd love to connect and collaborate!
        </span>
        <form id="contactForm" ref={form} onSubmit={sendEmail}>
          <input type="text" className="name" placeholder="Your Name" name="your_name" required />
          <input type="email" className="email" placeholder="Your Email" name="your_email" required />
          <textarea name="message" className="msg" rows="5" placeholder="Your Message" required></textarea>
          <br />
          <button className="submitBtn" type="submit">Submit</button>
        </form>
      </div>
    </section>
  );
};

export default Contact;
