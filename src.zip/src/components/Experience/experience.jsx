import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { VerticalTimeline, VerticalTimelineElement } from 'react-vertical-timeline-component';
import 'react-vertical-timeline-component/style.min.css';
import { FaLaptopCode, FaUniversity } from 'react-icons/fa';
import "./Experience.css";

const Experience = () => {
  useEffect(() => {
    AOS.init({
      duration: 1000, // Animation speed
      offset: 150, // Trigger animation 150px before element comes into view
      once: false, // Animates again when scrolling up
    });
  }, []);

  return (
    <section id="experience" className="experience">
      <div className="experience-container">
        <h1 className="experienceTitle" data-aos="fade-up">Experience</h1>
        
        <VerticalTimeline>
          {/* Algobulls Internship */}
          <VerticalTimelineElement
            className="vertical-timeline-element--work"
            contentStyle={{ background: '#1E3A8A', color: '#fff' }}
            contentArrowStyle={{ borderRight: '7px solid #1E3A8A' }}
            date="March 2024 - July 2024"
            iconStyle={{ background: '#1E3A8A', color: '#fff' }}
            icon={<FaLaptopCode />}
            data-aos="fade-up"
          >
            <h3 className="vertical-timeline-element-title">Python Developer</h3>
            <h4 className="vertical-timeline-element-subtitle">Algobulls Pvt Ltd</h4>
            <p>
              <ul>
                <li>Developed algorithmic trading strategies using Python.</li>
                <li>Integrated models into the trading platform, gaining insights into financial markets.</li>
              </ul>
            </p>
          </VerticalTimelineElement>

          {/* Education */}
          <VerticalTimelineElement
            className="vertical-timeline-element--education"
            contentStyle={{ background: '#374151', color: '#fff' }}
            contentArrowStyle={{ borderRight: '7px solid #374151' }}
            date="2023 - 2025"
            iconStyle={{ background: '#DC2626', color: '#fff' }}
            icon={<FaUniversity />}
            data-aos="fade-up"
          >
            <h3 className="vertical-timeline-element-title">M.Sc. IT</h3>
            <h4 className="vertical-timeline-element-subtitle">S.I.E.S College, Mumbai</h4>
            <p>Currently pursuing, expected completion in 2025.</p>
          </VerticalTimelineElement>

          <VerticalTimelineElement
            className="vertical-timeline-element--education"
            contentStyle={{ background: '#374151', color: '#fff' }}
            contentArrowStyle={{ borderRight: '7px solid #374151' }}
            date="2023"
            iconStyle={{ background: '#DC2626', color: '#fff' }}
            icon={<FaUniversity />}
            data-aos="fade-up"
          >
            <h3 className="vertical-timeline-element-title">B.Sc. IT</h3>
            <h4 className="vertical-timeline-element-subtitle">S.I.E.S College, Mumbai</h4>
            <p>Graduated with an 8.13 CGPA.</p>
          </VerticalTimelineElement>

          <VerticalTimelineElement
            className="vertical-timeline-element--education"
            contentStyle={{ background: '#374151', color: '#fff' }}
            contentArrowStyle={{ borderRight: '7px solid #374151' }}
            date="2020"
            iconStyle={{ background: '#DC2626', color: '#fff' }}
            icon={<FaUniversity />}
            data-aos="fade-up"
          >
            <h3 className="vertical-timeline-element-title">HSC</h3>
            <h4 className="vertical-timeline-element-subtitle">Andhra Education Society's Junior College</h4>
            <p>Graduated with 63%.</p>
          </VerticalTimelineElement>

          <VerticalTimelineElement
            className="vertical-timeline-element--education"
            contentStyle={{ background: '#374151', color: '#fff' }}
            contentArrowStyle={{ borderRight: '7px solid #374151' }}
            date="2018"
            iconStyle={{ background: '#DC2626', color: '#fff' }}
            icon={<FaUniversity />}
            data-aos="fade-up"
          >
            <h3 className="vertical-timeline-element-title">SSC</h3>
            <h4 className="vertical-timeline-element-subtitle">Andhra Education Society's Junior College</h4>
            <p>Graduated with 59.20%.</p>
          </VerticalTimelineElement>
        </VerticalTimeline>
      </div>
    </section>
  );
};

export default Experience;
