import React, { useEffect, useRef, useState } from 'react';
import emailjs from '@emailjs/browser';
import './hireMe.css';

const HireMe = ({ onClose }) => {
    const popupRef = useRef(null);
    const formRef = useRef(null);
    
    const [formData, setFormData] = useState({
        your_name: '',
        your_email: '',
        your_number: '',
        role: '',
        jobType: '',
        appointment_date: '',
        message: ''
    });

    const [errors, setErrors] = useState({});

    // ✅ Close pop-up when clicking outside
    const handleClickOutside = (event) => {
        if (popupRef.current && !popupRef.current.contains(event.target)) {
            onClose();
        }
    };

    useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // ✅ Disable past dates
    const today = new Date().toISOString().split("T")[0];

    // ✅ Form validation
    const validateForm = () => {
        let newErrors = {};

        if (!formData.your_name.trim()) newErrors.your_name = "Name is required.";
        if (!formData.your_email.trim()) {
            newErrors.your_email = "Email is required.";
        } else if (!/\S+@\S+\.\S+/.test(formData.your_email)) {
            newErrors.your_email = "Invalid email format.";
        }
        if (!formData.your_number.trim()) {
            newErrors.your_number = "Phone number is required.";
        } else if (!/^\d{10}$/.test(formData.your_number)) {
            newErrors.your_number = "Invalid phone number (10 digits required).";
        }
        if (!formData.appointment_date.trim()) newErrors.appointment_date = "Appointment date is required.";
        if (!formData.message.trim()) newErrors.message = "Message is required.";

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const sendEmail = (e) => {
        e.preventDefault();

        if (!validateForm()) return;

        emailjs
            .sendForm("service_jhr628a", "template_3kn3qoq", formRef.current, {
                publicKey: "Hzl05hDOtUlsxbJ0y",
            })
            .then(() => {
                alert("Message sent successfully, we will acknowledge and reply as soon as possible!");
                setFormData({
                    your_name: '',
                    your_email: '',
                    your_number: '',
                    role: '',
                    jobType: '',
                    appointment_date: '',
                    message: ''
                });
                setErrors({});
                onClose();
            })
            .catch(error => {
                console.log("FAILED...", error.text);
            });
    };

    return (
        <div className="popupOverlay">
            <div className="popupContainer" ref={popupRef}>
                <button className="closeBtn" onClick={onClose}>✖</button>
                <h2 className="hireMeTitle">Hire Me</h2>
                
                <form ref={formRef} className="hireMeForm" onSubmit={sendEmail}>
                    <input type="text" name="your_name" placeholder="Your Name" value={formData.your_name} onChange={handleChange} />
                    {errors.your_name && <span className="error">{errors.your_name}</span>}

                    <input type="email" name="your_email" placeholder="Your Email" value={formData.your_email} onChange={handleChange} />
                    {errors.your_email && <span className="error">{errors.your_email}</span>}

                    <input type="tel" name="your_number" placeholder="Your Phone Number" value={formData.your_number} onChange={handleChange} />
                    {errors.your_number && <span className="error">{errors.your_number}</span>}

                    <select name="role" value={formData.role} onChange={handleChange}>
                        <option value="">Select Role</option>
                        <option value="developer">Developer</option>
                        <option value="designer">Designer</option>
                        <option value="Software Engineer">Software Engineer</option>
                    </select>

                    <select name="jobType" value={formData.jobType} onChange={handleChange}>
                        <option value="">Select Job Type</option>
                        <option value="fulltime">Full Time</option>
                        <option value="parttime">Part Time</option>
                        <option value="Freelance">Freelance</option>
                    </select>

                    <input type="date" name="appointment_date" min={today} value={formData.appointment_date} onChange={handleChange} />
                    {errors.appointment_date && <span className="error">{errors.appointment_date}</span>}

                    <textarea name="message" placeholder="Describe Your Project" value={formData.message} onChange={handleChange}></textarea>
                    {errors.message && <span className="error">{errors.message}</span>}

                    <button type="submit" className="submitBtn1">Submit</button>
                </form>
            </div>
        </div>
    );
};

export default HireMe;
