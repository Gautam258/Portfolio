// import React, { useEffect, useRef } from 'react';
// import { useNavigate } from 'react-router-dom'; // Import useNavigate
// import './intro.css';
// import bg from '../../asset/intro_bg.png';

// // import bg from '../../asset/image5.png';
// import btnImg from '../../asset/BgImg.png';
// import Typed from 'typed.js';
// import pdf from "../../pdf/Resume.pdf";
// import { FaFileDownload } from "react-icons/fa";


// const Intro = () => {
//     const typedRef = useRef(null);
//     const navigate = useNavigate(); // Hook for navigation

//     useEffect(() => {
//         const typed = new Typed(typedRef.current, {
//             strings: ["Coder", "Developer", "Web Designer"],
//             typeSpeed: 50,
//             backSpeed: 50,
//             loop: true
//         });

//         return () => {
//             typed.destroy();
//         };
//     }, []);

//     return (
//         <section className="info">
//             <div className="infoContent"
//             data-aos="fade-up-right"
//             data-aos-duration="1000">
//                 <span className="hello">Hello</span>

//                 <span className="introText">
//                     I'm <span className="introName" ref={typedRef}></span>
//                 </span>

//                 <p className="introPara">
//                     I am a skilled and passionate web designer with experience <br />
//                     in creating visually appealing and user-friendly websites.
//                 </p>

//                 <div className="buttonContainer">
//                     <button className='btn' onClick={() => navigate('/hire')}>
//                         <img src={btnImg} alt='Profile' className='btnImg' /> Hire Me
//                     </button>
//                     <a href={pdf} download="Resume.pdf">
//                         <button className='btn1'>
//                         <FaFileDownload className="downloadIcon" /> Download

//                         </button>
//                     </a>
//                 </div>

//             </div>
//             <img src={bg} alt="Profile" className='bg' data-aos="fade-down-left"
//             data-aos-duration="1000"></img>
//         </section>
//     );
// };

// export default Intro;


import React, { useEffect, useRef, useState } from 'react';
import './intro.css';
import bg from '../../asset/intro_bg.png';
import btnImg from '../../asset/BgImg.png';
import Typed from 'typed.js';
import pdf from "../../pdf/Resume.pdf";
import { FaFileDownload } from "react-icons/fa";
import HireMe from '../Hire/Hire'; // Import HireMe form

const Intro = () => {
    const typedRef = useRef(null);
    const [showPopup, setShowPopup] = useState(false); // State to control popup

    useEffect(() => {
        const typed = new Typed(typedRef.current, {
            strings: ["Coder", "Developer", "Web Designer"],
            typeSpeed: 50,
            backSpeed: 50,
            loop: true
        });

        return () => {
            typed.destroy();
        };
    }, []);

    return (
        <section className="info">
            <div className="infoContent" data-aos="fade-up-right" data-aos-duration="1000">
                <span className="hello">Hello</span>
                <span className="introText">
                    I'm <span className="introName" ref={typedRef}></span>
                </span>
                <p className="introPara">
                    I am a skilled and passionate web designer with experience <br />
                    in creating visually appealing and user-friendly websites.
                </p>

                <div className="buttonContainer">
                    {/* Open Popup when button clicked */}
                    <button className='btn' onClick={() => setShowPopup(true)}>
                        <img src={btnImg} alt='Profile' className='btnImg' /> Hire Me
                    </button>
                    <a href={pdf} download="Resume.pdf">
                        <button className='btn1'>
                            <FaFileDownload className="downloadIcon" /> Download
                        </button>
                    </a>
                </div>
            </div>
            <img src={bg} alt="Profile" className='bg' data-aos="fade-down-left" data-aos-duration="1000"></img>

            {/* Hire Me Popup */}
            {showPopup && <HireMe onClose={() => setShowPopup(false)} />}  
        </section>
    );
};

export default Intro;
