import React, { useState } from "react";
import "./navbar.css";
import logo from "../../asset/logo.png";
import contactImg from "../../asset/contact.png";
import menu from "../../asset/menu.png";
import { Link } from "react-scroll"; // For smooth scrolling
import { useLocation, useNavigate } from "react-router-dom"; // For navigation

const Navbar = () => {
  const [showMenu, setShowMenu] = useState(false);
  const location = useLocation(); // Detects current route
  const navigate = useNavigate(); // Used for navigation

  // Function to handle navigation and scrolling
  const handleNavigation = (sectionId) => {
    if (location.pathname === "/") {
      // Scroll directly if on the homepage
      setTimeout(() => {
        document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 100);
    } else {
      // Navigate to the homepage first, then scroll
      navigate("/");
      setTimeout(() => {
        const checkElement = setInterval(() => {
          const element = document.getElementById(sectionId);
          if (element) {
            element.scrollIntoView({ behavior: "smooth", block: "start" });
            clearInterval(checkElement);
          }
        }, 300); // Retry every 300ms until the element is found
      }, 800); // Allow time for the page to load
    }
  };

  return (
    <nav className="navbar" data-aos="fade-down" data-aos-duration="1000">
      {/* Logo */}
      <Link to="info" smooth={true} offset={-100} duration={500}>
        <img src={logo} alt="Logo" className="logo" />
      </Link>

      {/* Desktop Navigation */}
      <div className="desktopMenu">
        {location.pathname === "/" ? (
          <>
            <Link to="info" smooth={true} offset={-100} duration={500} className="desktopMenuListItem">
              Home
            </Link>
            <Link to="AboutMe" smooth={true} offset={-90} duration={500} className="desktopMenuListItem">
              About
            </Link>
            <Link to="experience" smooth={true} offset={-80} duration={500} className="desktopMenuListItem">
              Experience
            </Link>
            <Link to="projects" smooth={true} offset={-30} duration={500} className="desktopMenuListItem">
              Projects
            </Link>
          </>
        ) : (
          <>
            <span className="desktopMenuListItem" onClick={() => handleNavigation("info")}>
              Home
            </span>
            <span className="desktopMenuListItem" onClick={() => handleNavigation("AboutMe")}>
              About
            </span>
            <span className="desktopMenuListItem" onClick={() => handleNavigation("experience")}>
              Experience
            </span>
            <span className="desktopMenuListItem" onClick={() => handleNavigation("projects")}>
              Projects
            </span>
            <span className="desktopMenuListItem" onClick={() => handleNavigation("contact")}>
            Contact Me
          </span>
          </>
        )}
      </div>

      {/* Contact Button */}
      {location.pathname === "/" && (
        <Link
          to="contact"
          smooth={true}
          offset={-100}
          duration={500}
          className="desktopMenuBtn"
        >
          <img src={contactImg} alt="Contact" className="desktopMenuImg" />
          Contact Me
        </Link>
      )}

      {/* Mobile Menu */}
      <img src={menu} alt="Menu" className="mobMenu" onClick={() => setShowMenu(!showMenu)} />
      <div className="navMenu" style={{ display: showMenu ? "flex" : "none" }}>
        {location.pathname === "/" ? (
          <>
            <Link to="info" smooth={true} offset={-100} duration={500} className="ListItem" onClick={() => setShowMenu(false)}>
              Home
            </Link>
            <Link to="AboutMe" smooth={true} offset={-90} duration={500} className="ListItem" onClick={() => setShowMenu(false)}>
              About
            </Link>
            <Link to="experience" smooth={true} offset={-80} duration={500} className="ListItem" onClick={() => setShowMenu(false)}>
              Experience
            </Link>
            <Link to="projects" smooth={true} offset={-30} duration={500} className="ListItem" onClick={() => setShowMenu(false)}>
              Projects
            </Link>
            <Link to="contact" smooth={true} offset={-100} duration={500} className="ListItem" onClick={() => setShowMenu(false)}>
            Contact Me
            </Link>
          </>
        ) : (
          <>
            <span className="ListItem" onClick={() => { handleNavigation("info"); setShowMenu(false); }}>Home</span>
            <span className="ListItem" onClick={() => { handleNavigation("AboutMe"); setShowMenu(false); }}>About</span>
            <span className="ListItem" onClick={() => { handleNavigation("experience"); setShowMenu(false); }}>Experience</span>
            <span className="ListItem" onClick={() => { handleNavigation("projects"); setShowMenu(false); }}>Projects</span>
            <span className="ListItem" onClick={() => { handleNavigation("contact"); setShowMenu(false); }}>Contact Me</span>
          </>
        )}

       
      </div>
    </nav>
  );
};

export default Navbar;
