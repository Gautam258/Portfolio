import React, { useState } from "react";
import "./Projects.css";

// Import Technology Icons
import { 
  SiReact, SiCss3, SiHtml5, SiJavascript, SiFigma, 
  SiPython, SiOpencv, SiNumpy, SiMediapipe 
} from "react-icons/si";

// Import Images
import powerImage from "../../asset/power.png";  // Power image replacing Power BI icon
import microsoftImage from "../../asset/microsoft.png";  // Microsoft image replacing SQL icon

import bgTabOne1 from "../../asset/image.png"; 
import bgTabOne2 from "../../asset/image3.png";
import bgTabOne3 from "../../asset/website_image.png";
import bgTabTwo from "../../asset/gesture.png";
import bgTabTwo1 from "../../asset/computer.png";
import bgTabTwo2 from "../../asset/air.png";
import bgTabThree from "../../asset/sales.png"; 
import bgTabThree1 from "../../asset/financial.png"; 
import bgTabThree2 from "../../asset/netflix.png"; 

const Projects = () => {
  const [activeTab, setActiveTab] = useState("tabOne");
  const [expandedProject, setExpandedProject] = useState(null);

  const tabs = {
    tabOne: [
      { 
        id: 1, 
        title: "Travel The World", 
        description: "Explore amazing destinations.", 
        technologies: [<SiReact />, <SiCss3 />], 
        bg: bgTabOne1 
      },
      { 
        id: 2, 
        title: "Freelancer Website Design", 
        description: "Creative design and development services with a professional layout.", 
        technologies: [<SiHtml5 />, <SiCss3 />, <SiJavascript />, <SiFigma />], 
        bg: bgTabOne2 
      },
      { 
        id: 3, 
        title: "Spotify Interface", 
        description: "Spotify clone with music playback controls, playlists, and a user-friendly navigation panel.", 
        technologies: [<SiHtml5 />, <SiCss3 />, <SiJavascript />, <SiReact />], 
        bg: bgTabOne3 
      },
    ],
    tabTwo: [
      { 
        id: 1, 
        title: "Gesture-Controlled Media", 
        description: "Developed an interface that allows users to control media playback through hand gestures using MediaPipe's hand-tracking capabilities.", 
        technologies: [<SiPython />, <SiOpencv />, <SiMediapipe />], 
        bg: bgTabTwo 
      },
      { 
        id: 2, 
        title: "Computer Vision Techniques", 
        description: "Explored YOLO for real-time object detection, classification, segmentation, tracking, and pose estimation.", 
        technologies: [<SiPython />, <SiOpencv />, <SiNumpy />], 
        bg: bgTabTwo1 
      },
      { 
        id: 3, 
        title: "Air Canvas MediaPipe", 
        description: "Created a virtual drawing interface that tracks finger movements to allow users to draw or write digitally.", 
        technologies: [<SiPython />, <SiOpencv />, <SiMediapipe />], 
        bg: bgTabTwo2 
      },
    ],
    tabThree: [
      { 
        id: 1, 
        title: "Financial Performance Analysis", 
        description: "Optimizing financial analysis for a firm that provides accounting services to clients.", 
        technologies: [<img src={powerImage} alt="Power" className="tech-img" />, <img src={microsoftImage} alt="Microsoft" className="tech-img" />], 
        bg: bgTabThree1 
      },
      { 
        id: 2, 
        title: "OTT Media Dashboard", 
        description: "OTT platforms like Netflix and Amazon Prime use user data to personalize recommendations.", 
        technologies: [<img src={powerImage} alt="Power" className="tech-img" />, <img src={microsoftImage} alt="Microsoft" className="tech-img" />], 
        bg: bgTabThree2 
      },
      { 
        id: 3, 
        title: "Works Database Analysis", 
        description: "Analyzing business about sales, product performance, and customer behavior.", 
        technologies: [<img src={powerImage} alt="Power" className="tech-img" />, <img src={microsoftImage} alt="Microsoft" className="tech-img" />], 
        bg: bgTabThree 
      },
    ],
  };

  const toggleExpand = (projectId) => {
    setExpandedProject(expandedProject === projectId ? null : projectId);
  };

  return (
    <section id="projects" className="projects">
      <div className="projects-container">
        <h1 className="projectTitle">Projects</h1>

        {/* Tab Buttons */}
        <div className="tabs">
          <button className={`tab-button ${activeTab === "tabOne" ? "active" : ""}`} onClick={() => setActiveTab("tabOne")}>Website</button>
          <button className={`tab-button ${activeTab === "tabThree" ? "active" : ""}`} onClick={() => setActiveTab("tabThree")}>Power BI</button>
          <button className={`tab-button ${activeTab === "tabTwo" ? "active" : ""}`} onClick={() => setActiveTab("tabTwo")}>Machine Learning</button>
        </div>

        {/* Project Cards */}
        <div className="projects-grid">
          {tabs[activeTab].map((project) => (
            <div key={project.id} className={`project-card ${expandedProject === project.id ? "expanded" : ""}`} style={{ backgroundImage: `url(${project.bg})` }}>
              <div className="overlay">
                <h3 className="project-heading">{project.title}</h3>
                <button className="read-more-button" onClick={() => toggleExpand(project.id)}>
                  {expandedProject === project.id ? "Show Less" : "Show More"}
                </button>

                {/* Expanded Content Inside the Card */}
                {expandedProject === project.id && (
                  <div className="expanded-content">
                    <p className="project-description"><strong>Description:</strong></p>
                    <p className="project-description1"> {project.description}</p>
                    <h4 className="expanded-tech-title">Technologies Used:</h4>
                    <div className="expanded-tech-list">
                      {project.technologies.map((tech, index) => (
                        <span key={index} className="tech-icon">{tech}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
